from django.shortcuts import render,redirect 
from .models import Contact 
from .forms import ContactForm

# Create your views here.


# Create your views here.

def addview(request):
    form=ContactForm()
    if request.method=='POST':
        form=ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/a1/show/')
    return render(request,'app1/add.html',{'form':form})    

def showview(request):
    queryset=Contact.objects.all()
    return render(request,'app1/show.html',{'query':queryset})
    
    
def updateview(request,pk):
    obj=Contact.objects.get(pk=id)
    form=ContactForm()
    if request.method=='POST':
        form=ContactForm(request.POST,instance=obj)
        if form.is_valid():
            form.save()
            return redirect('/a1/show/')
    return render(request,'app1/add.html',{'form':form})
        
        
def deleteview(request,x):
    obj=Contact.objects.get(x=id)
    if request.method=='POST':
        obj.delete()
    return render(request,'app1.delete.html',{})            