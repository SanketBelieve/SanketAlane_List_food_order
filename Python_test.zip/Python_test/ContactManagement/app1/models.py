from django.db import models

# Create your models here.
class Contact(models.Model):
    id=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=45)
    email=models.EmailField()
    phone=models.CharField(max_length=15)
    address=models.CharField(max_length=200)
    